package com.example.ca3

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@Entity(tableName = "shopping_items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Int
)

@Dao
interface ShoppingDao {
    @Insert
    suspend fun insertItem(item: Item)

    @Query("SELECT * FROM shopping_items")
    fun getAllItems(): Flow<List<Item>>

    @Query("SELECT COUNT(*) FROM shopping_items")
    suspend fun getItemCount(): Int
}

class ShoppingRepository : ShoppingDao {
    private val _items = MutableStateFlow<List<Item>>(emptyList())

    override suspend fun insertItem(item: Item) {
        val newItem = item.copy(id = _items.value.size + 1)
        _items.value = _items.value + newItem
    }

    override fun getAllItems(): Flow<List<Item>> = _items.asStateFlow()

    override suspend fun getItemCount(): Int = _items.value.size
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
                    ShoppingListScreen(Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
fun ShoppingListScreen(modifier: Modifier = Modifier) {
    val repository = remember { ShoppingRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val items by repository.getAllItems().collectAsState(initial = emptyList())

    var name by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Shopping List App",
            style = MaterialTheme.typography.headlineSmall
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Item Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Quantity") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val qty = quantityText.toIntOrNull() ?: 1
                        if (name.isNotBlank()) {
                            scope.launch {
                                val count = repository.getItemCount()
                                if (count >= 3) {
                                    Toast.makeText(
                                        context,
                                        "Limit reached! Max 3 items allowed.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    repository.insertItem(Item(name = name, quantity = qty))
                                    name = ""
                                    quantityText = ""
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Add Item")
                }
            }
        }

        Text(
            text = "Shopping Items (${items.size}/3):",
            style = MaterialTheme.typography.titleMedium
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(items) { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = item.name, style = MaterialTheme.typography.bodyLarge)
                        Text(text = "Qty: ${item.quantity}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
